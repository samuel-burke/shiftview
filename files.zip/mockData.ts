export type ShiftType = "opener" | "mid" | "closer";

export type Employee = {
  id: number;
  name: string;
  avatar: string;
};

export type Schedule = {
  id: number;
  employeeId: number;
  date: string;
  startMinutes: number; // -1 = off/not scheduled
  endMinutes: number;
  startLabel: string;
  endLabel: string;
};

export const employees: Employee[] = [
  { id: 1,  name: "Marcus T.",  avatar: "MT" },
  { id: 2,  name: "Janelle R.", avatar: "JR" },
  { id: 3,  name: "Deon W.",    avatar: "DW" },
  { id: 4,  name: "Priya M.",   avatar: "PM" },
  { id: 5,  name: "Carlos S.",  avatar: "CS" },
  { id: 6,  name: "Kevin L.",   avatar: "KL" },
  { id: 7,  name: "Ray V.",     avatar: "RV" },
  { id: 8,  name: "Aaliyah F.", avatar: "AF" },
  { id: 9,  name: "Simone H.",  avatar: "SS" },
  { id: 10, name: "Brett O.",   avatar: "BO" },
  { id: 11, name: "Jordan L.",  avatar: "JL" },
];

// Simulated now = 1:00 PM = 780 min
// Openers  6:00 AM – 2:30 PM  (360–870)   → here at 1pm ✓
// Mids    10:00 AM – 6:30 PM  (600–1110)  → here at 1pm ✓
// Closers  2:00 PM – 10:30 PM (840–1290)  → not yet in  ✗
export const schedules: Schedule[] = [
  { id: 1,  employeeId: 1,  date: "2026-05-19", startMinutes: 360,  endMinutes: 870,  startLabel: "6:00 AM",  endLabel: "2:30 PM"  },
  { id: 2,  employeeId: 2,  date: "2026-05-19", startMinutes: 360,  endMinutes: 870,  startLabel: "6:00 AM",  endLabel: "2:30 PM"  },
  { id: 3,  employeeId: 6,  date: "2026-05-19", startMinutes: 360,  endMinutes: 870,  startLabel: "6:00 AM",  endLabel: "2:30 PM"  },
  { id: 4,  employeeId: 4,  date: "2026-05-19", startMinutes: 600,  endMinutes: 1110, startLabel: "10:00 AM", endLabel: "6:30 PM"  },
  { id: 5,  employeeId: 5,  date: "2026-05-19", startMinutes: 600,  endMinutes: 1110, startLabel: "10:00 AM", endLabel: "6:30 PM"  },
  { id: 6,  employeeId: 3,  date: "2026-05-19", startMinutes: 600,  endMinutes: 1110, startLabel: "10:00 AM", endLabel: "6:30 PM"  },
  { id: 7,  employeeId: 7,  date: "2026-05-19", startMinutes: 840,  endMinutes: 1290, startLabel: "2:00 PM",  endLabel: "10:30 PM" },
  { id: 8,  employeeId: 8,  date: "2026-05-19", startMinutes: 840,  endMinutes: 1290, startLabel: "2:00 PM",  endLabel: "10:30 PM" },
  { id: 9,  employeeId: 9,  date: "2026-05-19", startMinutes: 840,  endMinutes: 1290, startLabel: "2:00 PM",  endLabel: "10:30 PM" },
  { id: 10, employeeId: 10, date: "2026-05-19", startMinutes: -1,   endMinutes: -1,   startLabel: "",          endLabel: ""          },
  { id: 11, employeeId: 11, date: "2026-05-19", startMinutes: -1,   endMinutes: -1,   startLabel: "",          endLabel: ""          },
];

// Derived — computed from start time, not stored
export function getShiftType(startMinutes: number): ShiftType | null {
  if (startMinutes < 0) return null;
  if (startMinutes < 540) return "opener"; // before 9am
  if (startMinutes < 720) return "mid";    // 9am–noon
  return "closer";                          // noon+
}

// Is this person currently here given simulated now?
export function isHere(s: Schedule, nowMinutes: number): boolean {
  return s.startMinutes >= 0 && nowMinutes >= s.startMinutes && nowMinutes < s.endMinutes;
}

export const SHIFT_COLORS: Record<ShiftType, string> = {
  opener: "#f59e0b",
  mid:    "#6366f1",
  closer: "#8b5cf6",
};

export const OPTIMAL_COVERAGE = 7;
export const MINIMUM_COVERAGE = 5;

// Simulated current time for demo: 1:00 PM
export const SIM_NOW_MINUTES = 780;
