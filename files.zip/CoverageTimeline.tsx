"use client";

import { useMemo } from "react";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ReferenceLine, ResponsiveContainer,
} from "recharts";
import { Schedule, SIM_NOW_MINUTES } from "../data/mockData";

type Props = { schedules: Schedule[]; nowMinutes: number };

const POINTS = [
  { label: "6AM",  m: 360  },
  { label: "8AM",  m: 480  },
  { label: "10AM", m: 600  },
  { label: "12PM", m: 720  },
  { label: "2PM",  m: 840  },
  { label: "4PM",  m: 960  },
  { label: "6PM",  m: 1080 },
  { label: "8PM",  m: 1200 },
  { label: "10PM", m: 1320 },
];

// Convert nowMinutes to the nearest label for ReferenceLine x value
function nowLabel(nowMinutes: number): string {
  // Find the label just before or at now
  let best = POINTS[0].label;
  for (const p of POINTS) {
    if (nowMinutes >= p.m) best = p.label;
  }
  return best;
}

// Format minutes as h:mm AM/PM
function fmtMinutes(m: number): string {
  const h = Math.floor(m / 60);
  const min = m % 60;
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return min === 0 ? `${h12}:00 ${ampm}` : `${h12}:${String(min).padStart(2, "0")} ${ampm}`;
}

export default function CoverageTimeline({ schedules, nowMinutes }: Props) {
  const data = useMemo(() => {
    return POINTS.map(({ label, m }) => ({
      label,
      staff: schedules.filter(
        s => s.startMinutes >= 0 && m >= s.startMinutes && m < s.endMinutes
      ).length,
    }));
  }, [schedules]);

  const refLabel = nowLabel(nowMinutes);
  const timeStr = fmtMinutes(nowMinutes);

  return (
    <div style={{ background: "#1a2236", borderRadius: 16, padding: "16px 10px 10px", marginBottom: 16 }}>
      <p style={{
        fontSize: 11, fontWeight: 700, letterSpacing: "0.1em",
        color: "#64748b", textTransform: "uppercase", marginBottom: 12, paddingLeft: 6,
      }}>
        Today's Coverage Timeline
      </p>
      <ResponsiveContainer width="100%" height={130}>
        <AreaChart data={data} margin={{ top: 10, right: 8, left: -28, bottom: 0 }}>
          <defs>
            <linearGradient id="covGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}    />
            </linearGradient>
          </defs>
          <XAxis
            dataKey="label"
            tick={{ fill: "#475569", fontSize: 10 }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            tick={{ fill: "#475569", fontSize: 10 }}
            tickLine={false}
            axisLine={false}
            allowDecimals={false}
          />
          <Tooltip
            contentStyle={{
              background: "#0f172a",
              border: "1px solid #334155",
              borderRadius: 8,
              fontSize: 12,
              color: "#f1f5f9",
            }}
            formatter={(v: number) => [`${v} staff`, "Coverage"]}
          />
          {/* Current time reference line */}
          <ReferenceLine
            x={refLabel}
            stroke="#94a3b8"
            strokeDasharray="4 3"
            strokeWidth={1.5}
            label={{
              value: timeStr,
              position: "top",
              fill: "#94a3b8",
              fontSize: 9,
              fontWeight: 600,
            }}
          />
          <Area
            type="monotone"
            dataKey="staff"
            stroke="#3b82f6"
            strokeWidth={2.5}
            fill="url(#covGrad)"
            dot={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
